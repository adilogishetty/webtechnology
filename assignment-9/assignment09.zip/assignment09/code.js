function myFunction()
{
	document.getElementById("infoo").style.display='inherit';
}

function myFunction1() 
{
	confirm("Are you sure?");
}

