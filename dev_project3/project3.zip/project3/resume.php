<!DOCTYPE HTML>
<html lang="en-US">

<head>
<title>ADITYA LOGISHETTY</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="description" 
                content="A sample resume of my professional technical skills and background">
<meta name="keywords" 
                content="charset, content, http-equiv, itemprop, name, property,resume, porfolio, cover letter, skills, education, academic, experience, gpa, university,interview, job, search, career, professional, download">
<meta name="author" 
               content="ADITYA LOGISHETTY">
<link rel="stylesheet"  type="text/css" href="style.css">


<script>
	src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<style>

h2 {
    color: darkblue;
    margin-left: 40px;
} 
</style>

</head>
<body>
<script type="text/javascript" src="mystyle.js"></script>

<br>
<article>
<h2>Objective</h2>
<p id="obj"></p>
<button type="button" onclick="myFunction()">Click to view</button>

<h2>Education</h2>

<table style="width:70%">


<tr>
<th>College/School</th>
<th>Course</th>
<th>grades</th>
</tr>
<tr>
<td>Marist college,NY,USA.</td>
<td>Information system management</td>
<td>gpa-3.7</td>
</tr>
<tr>
<td>JNTUH,Telangana,INDIA</td>
<td>Computer science</td>
<td id="grade">70%</td>
</tr>
</table>

<h2>Skills</h2>
<ul>
<li>	Programming Languages: Java, C++, Python.</li>
<li>Application tools        : MS Office, adobe Photoshop</li>
<li>Web Technologies      : HTML, Java script</li>
</ul>


<h2>Community involvment</h2>
<ul>
<li>Organized events for the awareness of education </li>
<li>Volunteer, Global Support Organization and Hope for Children</li>
</ul>

<h2>Engineering project</h2>
<dl>
<dt><b>Identification Wallet-</b></dt>
<dd>The main objective of the project is to access any document such as license, passport etc. from anywhere anytime. Thus avoiding people to carry documents and losing them. Thus making it simpler and easier for one to carry all their documents and to produce them wherever and whenever required.</dd>
<dt><b>Intelligent Threat Analysis And Report Generation-</b></dt> 
<dd>In todays modern defense systems capturing enemies spread across the border and generating report about enemy activities on Geo Information System (GIS) will help users to arrive at decision regarding next action to be executed is key analysis component for commanders. As the data generated through various sub systems/systems/group of systems has become more complex and due to various technological limitations for interpretation of data, intelligent analysis and report generation systems has been devised to resolve the data accessibility  and to utilize the data using artificial intelligence techniques.Analysis functionality provides the features to analyze various reports collated and aids the operator to draw the conclusions like situational awareness and common operational picture to know the enemy strength.
The details of Emitter data, mobile information, Call sign and Group related information must be retrieved from the data base (DB) and to be displayed in spectral and temporal views. These data representations shall be useful in analysis of Emitter data by giving an overall picture of Emitter Concentration, Signal Strength, Time of Operation.</dd>
</dl>

<h2>Experience/Internships</h2>
<ul>
<li>Completed Training in "CS/IT FIELD" - Regional Telecom Training Center, BSNL, Hyderabad.</li> 
<li>Worked as intern on "Database Management" at Digital Minds Software Solutions Pvt. Ltd., India.</li>
</ul>

</article>

<hr>
<p><b>Link to download resume:</b></p>
<p><a href="https://drive.google.com/file/d/0B3m1UhAoNmFOYzhJS0ZsUEFJd0U/view" target="_blank">Download</a></p>
<br>




</body>
</html>