
function myFunction() {
    document.getElementById("obj").innerHTML = "Graduate in Information Systems Management actively seeking summer internships to better enhance my skills. An aspiring individual aiming to help achieve company goals and objectives.";
}