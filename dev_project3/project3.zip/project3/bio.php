<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Bio</title>
<link rel="stylesheet" href="code.css">
<script type="text/javascript" src="code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<style>

.image{
 width:220px;
    margin: 5px;
    height:100%;
}
</style>
</head>
<body style= "background-image: url(sample.jpg)">
 
  <div id="tab2"><!-- page 2 -->
<br><br>
<div class="image" style="float: left;">
		<nav>
			<img src="adi.jpg" alt="aditya" width="220" height="200">
		</nav>
	</div>
<br><br><h1 style="font-family:Georgia; font-size:150%; text-align:left;">Aditya Logishetty</h1><br>
<br><br><br><br><br>
<div id ="bio">
	<p style = "font-family:Arial bold; font-size:100%">"Aditya has moved to New York,USA from Telangana,INDIA to pursue his masters in Information systems management at Marist College. He has done his undergraduate in computer science in JNTUH. </p>
<p style = "font-family:Arial bold; font-size:100%">"He has done internships in data base management systems and gained certificates regarding information Technology.He has also served many Non-Government Organization such as Street Cause Gold and Helping hands."  </p>
</div>
</div><!-- /tab2 -->
</body>
</html>